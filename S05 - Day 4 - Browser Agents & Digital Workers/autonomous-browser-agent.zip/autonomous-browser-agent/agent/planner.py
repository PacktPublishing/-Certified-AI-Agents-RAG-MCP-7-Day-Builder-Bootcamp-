def create_browser_plan(goal: str, target_sites: list[str]) -> list[str]:
    return [
        "Open each target website",
        "Extract page title and main headings",
        "Collect visible page text",
        "Identify feature and pricing-related information",
        "Save extracted data",
        "Generate final research report"
    ]