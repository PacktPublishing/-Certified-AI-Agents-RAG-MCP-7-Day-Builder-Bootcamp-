from agent.state import BrowserTaskState
from agent.planner import create_browser_plan
from browser.browser_controller import BrowserController
from browser.extractor import extract_relevant_sections
from reports.report_generator import generate_report
from tools.file_tools import save_json, timestamped_filename

def safe_navigate(browser, site, retries=3):
    last_error = None

    for attempt in range(1, retries + 1):
        try:
            browser.navigate(site)
            return True, None
        except Exception as error:
            last_error = str(error)

    return False, last_error

def make_safe_filename(text: str):
    safe = text.lower().replace(" ", "_").replace("/", "_").replace("\\", "_")
    safe = "".join(char for char in safe if char.isalnum() or char in ["_", "-"])
    return safe[:40] or "screenshot"

def run_browser_agent(goal: str, target_sites: list[str], headless: bool = True):
    state = BrowserTaskState(
        goal=goal,
        target_sites=target_sites
    )

    plan = create_browser_plan(goal, target_sites)

    browser = BrowserController(headless=headless)
    browser.start()

    try:
        for site in target_sites:
            success, error = safe_navigate(browser, site)

            if not success:
                state.errors.append(f"{site}: {error}")
                continue

            try:
                title = browser.get_title()
                current_url = browser.get_url()
                text = browser.get_visible_text()
                headings = browser.get_headings()
                relevant_sections = extract_relevant_sections(text)

                screenshot_name = make_safe_filename(title) + ".png"
                screenshot_path = browser.take_screenshot(screenshot_name)

                finding = {
                    "title": title,
                    "url": current_url,
                    "headings": headings,
                    "relevant_sections": relevant_sections,
                    "screenshot": screenshot_path
                }

                state.findings.append(finding)

            except Exception as error:
                state.errors.append(f"{site}: {str(error)}")

    finally:
        browser.close()

    json_filename = timestamped_filename("browser_agent_findings", "json")
    save_json(state.model_dump(), json_filename)

    report_path = generate_report(goal, plan, state.findings)
    state.report_path = report_path

    return {
        "goal": state.goal,
        "plan": plan,
        "findings": state.findings,
        "errors": state.errors,
        "report_path": state.report_path
    }

