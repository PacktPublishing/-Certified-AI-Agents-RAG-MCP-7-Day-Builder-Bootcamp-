from pydantic import BaseModel
from typing import List, Dict, Optional

class BrowserTaskState(BaseModel):
    goal: str
    target_sites: List[str]
    current_step: int = 0
    findings: List[Dict] = []
    errors: List[str] = []
    report_path: Optional[str] = None