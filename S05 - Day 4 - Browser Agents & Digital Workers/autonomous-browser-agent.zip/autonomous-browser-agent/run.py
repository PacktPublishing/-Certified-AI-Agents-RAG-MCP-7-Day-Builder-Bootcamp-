from agent.worker import run_browser_agent

TARGET_SITES = [
    "https://github.com/features/copilot",
    "https://www.anthropic.com/claude-code",
    "https://openai.com/codex"
]

if __name__ == "__main__":
    goal = "Research AI coding assistants and extract features, pricing, enterprise, and developer information."

    result = run_browser_agent(
        goal=goal,
        target_sites=TARGET_SITES,
        headless=False
    )

    print("\nBrowser Agent Complete")
    print("----------------------")
    print("Goal:", result["goal"])
    print("Report:", result["report_path"])

    if result["errors"]:
        print("\nErrors:")
        for error in result["errors"]:
            print("-", error)

