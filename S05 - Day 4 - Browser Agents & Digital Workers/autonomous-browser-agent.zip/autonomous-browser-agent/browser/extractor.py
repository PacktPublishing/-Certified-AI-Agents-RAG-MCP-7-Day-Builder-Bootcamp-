def extract_relevant_sections(text: str):
    keywords = [
        "feature",
        "pricing",
        "enterprise",
        "security",
        "integration",
        "agent",
        "coding",
        "developer",
        "automation"
    ]

    lines = text.split("\n")
    relevant_lines = []

    for line in lines:
        clean_line = line.strip()

        if not clean_line:
            continue

        lower = clean_line.lower()

        if any(keyword in lower for keyword in keywords):
            relevant_lines.append(clean_line)

    return relevant_lines[:40]
