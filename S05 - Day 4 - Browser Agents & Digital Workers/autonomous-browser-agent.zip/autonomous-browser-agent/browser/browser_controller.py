from playwright.sync_api import sync_playwright
from pathlib import Path

class BrowserController:
    def __init__(self, headless: bool = True):
        self.headless = headless
        self.playwright = None
        self.browser = None
        self.page = None

    def start(self):
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.launch(headless=self.headless)
        self.page = self.browser.new_page(accept_downloads=True)

    def navigate(self, url: str):
        self.page.goto(url, wait_until="domcontentloaded", timeout=60000)
        self.page.wait_for_timeout(2000)

    def get_title(self):
        return self.page.title()

    def get_url(self):
        return self.page.url

    def get_visible_text(self):
        return self.page.locator("body").inner_text(timeout=10000)

    def get_headings(self):
        headings = []

        for tag in ["h1", "h2", "h3"]:
            elements = self.page.locator(tag).all()

            for element in elements:
                try:
                    text = element.inner_text().strip()
                    if text:
                        headings.append({
                            "tag": tag,
                            "text": text
                        })
                except Exception:
                    continue

        return headings

    def take_screenshot(self, filename: str):
        Path("data/outputs").mkdir(parents=True, exist_ok=True)
        path = f"data/outputs/{filename}"
        self.page.screenshot(path=path, full_page=True)
        return path

    def fill_input(self, selector: str, value: str):
        self.page.fill(selector, value)

    def select_option(self, selector: str, value: str):
        self.page.select_option(selector, label=value)

    def click(self, selector: str):
        self.page.click(selector)

    def get_text_by_selector(self, selector: str):
        return self.page.locator(selector).inner_text()

    def download_file(self, selector: str):
        Path("data/downloads").mkdir(parents=True, exist_ok=True)

        with self.page.expect_download() as download_info:
            self.page.click(selector)

        download = download_info.value
        path = f"data/downloads/{download.suggested_filename}"
        download.save_as(path)

        return path

    def close(self):
        if self.browser:
            self.browser.close()

        if self.playwright:
            self.playwright.stop()
