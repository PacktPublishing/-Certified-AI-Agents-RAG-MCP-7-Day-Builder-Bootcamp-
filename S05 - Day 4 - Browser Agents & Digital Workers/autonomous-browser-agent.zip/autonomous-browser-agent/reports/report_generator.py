from tools.file_tools import save_text, timestamped_filename

def generate_report(goal: str, plan: list[str], findings: list[dict]):
    report = f"""# Autonomous Browser Agent Report

## Goal

{goal}

## Execution Plan

"""

    for index, step in enumerate(plan, start=1):
        report += f"{index}. {step}\n"

    report += "\n## Website Findings\n"

    for item in findings:
        report += f"""
### {item["title"]}

**URL:** {item["url"]}

**Screenshot:** {item.get("screenshot", "N/A")}

#### Headings
"""

        for heading in item.get("headings", [])[:10]:
            report += f"- {heading['tag'].upper()}: {heading['text']}\n"

        report += "\n#### Relevant Extracted Lines\n"

        for line in item.get("relevant_sections", [])[:20]:
            report += f"- {line}\n"

    report += """

## Summary

The browser agent successfully navigated the target websites, extracted visible information, identified relevant product and feature-related content, saved structured data, and generated this report.

## Recommended Next Steps

- Add LLM-based summarization
- Add site-specific extraction rules
- Add authentication support
- Add human-in-the-loop approval
- Add scheduled monitoring
"""

    filename = timestamped_filename("browser_agent_report", "md")
    return save_text(report, filename)

