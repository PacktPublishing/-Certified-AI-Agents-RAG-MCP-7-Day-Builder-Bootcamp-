from fastapi import FastAPI
from pydantic import BaseModel
from agent.worker import run_browser_agent

app = FastAPI(title="Autonomous Browser Agent")

class BrowserAgentRequest(BaseModel):
    goal: str
    target_sites: list[str]
    headless: bool = True

@app.get("/")
def home():
    return {
        "message": "Autonomous Browser Agent is running"
    }

@app.post("/run-browser-agent")
def run_agent(request: BrowserAgentRequest):
    return run_browser_agent(
        goal=request.goal,
        target_sites=request.target_sites,
        headless=request.headless
    )
