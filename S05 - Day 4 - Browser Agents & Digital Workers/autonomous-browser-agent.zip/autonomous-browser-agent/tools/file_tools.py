import json
from pathlib import Path
from datetime import datetime

OUTPUT_DIR = Path("data/outputs")
DOWNLOAD_DIR = Path("data/downloads")

def save_json(data, filename: str):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    path = OUTPUT_DIR / filename

    with path.open("w", encoding="utf-8") as file:
        json.dump(data, file, indent=2)

    return str(path)

def save_text(content: str, filename: str):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    path = OUTPUT_DIR / filename

    with path.open("w", encoding="utf-8") as file:
        file.write(content)

    return str(path)

def timestamped_filename(prefix: str, extension: str):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_{timestamp}.{extension}"
