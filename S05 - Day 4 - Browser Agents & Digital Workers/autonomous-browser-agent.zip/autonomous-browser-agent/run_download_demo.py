from browser.browser_controller import BrowserController

if __name__ == "__main__":
    browser = BrowserController(headless=False)
    browser.start()

    try:
        browser.navigate("http://localhost:9000")
        path = browser.download_file("a[download]")
        print("Downloaded file:", path)

    finally:
        browser.close()

