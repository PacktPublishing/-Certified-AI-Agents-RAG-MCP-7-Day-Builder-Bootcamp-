from browser.browser_controller import BrowserController

if __name__ == "__main__":
    browser = BrowserController(headless=False)
    browser.start()

    try:
        browser.navigate("http://localhost:9000")
        browser.fill_input("#topic", "AI coding assistant market research")
        browser.select_option("#priority", "High")
        browser.click("button")
        result = browser.get_text_by_selector("#result")

        print("Form completed successfully.")
        print("Result:", result)

    finally:
        browser.close()
