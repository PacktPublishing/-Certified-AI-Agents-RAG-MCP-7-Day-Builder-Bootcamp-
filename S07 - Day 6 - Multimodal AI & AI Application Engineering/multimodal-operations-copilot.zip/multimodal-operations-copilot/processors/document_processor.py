import fitz

def analyze_document(file_path: str):
    doc = fitz.open(file_path)

    pages = []
    full_text = ""

    for page_number, page in enumerate(doc, start=1):
        text = page.get_text()
        full_text += text + "\n"

        pages.append({
            "page": page_number,
            "text_preview": text[:1000]
        })

    keywords = extract_keywords(full_text)

    return {
        "file_path": file_path,
        "page_count": len(doc),
        "text": full_text[:5000],
        "keywords": keywords,
        "pages": pages
    }

def extract_keywords(text: str):
    keywords = [
        "incident",
        "latency",
        "error",
        "database",
        "outage",
        "monitoring",
        "alert",
        "rollback",
        "deployment",
        "capacity",
        "risk"
    ]

    found = []

    lower_text = text.lower()

    for keyword in keywords:
        if keyword in lower_text:
            found.append(keyword)

    return found
