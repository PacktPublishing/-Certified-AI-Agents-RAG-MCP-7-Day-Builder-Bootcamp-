def generate_recommendations(fused_result):
    severity = fused_result["severity"]
    themes = fused_result["operational_themes"]

    recommendations = []

    if "Latency" in themes:
        recommendations.append("Check API response time, recent deployments, and downstream dependencies.")

    if "Database" in themes:
        recommendations.append("Review database CPU, memory, locks, slow queries, and connection pool usage.")

    if "Errors" in themes:
        recommendations.append("Inspect error logs, failed requests, and recent service exceptions.")

    if "Capacity" in themes:
        recommendations.append("Evaluate scaling policies and resource utilization.")

    if severity == "High":
        recommendations.append("Escalate to incident commander and initiate incident response workflow.")

    if not recommendations:
        recommendations.append("Continue monitoring and gather additional evidence.")

    return recommendations
