import whisper

_model = None

def get_model():
    global _model

    if _model is None:
        _model = whisper.load_model("base")

    return _model

def transcribe_audio(file_path: str):
    model = get_model()
    result = model.transcribe(file_path)

    text = result.get("text", "")

    return {
        "file_path": file_path,
        "transcript": text,
        "language": result.get("language"),
        "segments": [
            {
                "start": segment["start"],
                "end": segment["end"],
                "text": segment["text"]
            }
            for segment in result.get("segments", [])
        ][:10]
    }