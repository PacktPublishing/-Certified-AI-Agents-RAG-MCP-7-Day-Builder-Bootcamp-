from processors.copilot_recommendations import generate_recommendations

def fuse_multimodal_inputs(document_result, image_result, audio_result):
    document_keywords = document_result.get("keywords", [])
    transcript = audio_result.get("transcript", "")

    operational_themes = []

    combined_text = (
        document_result.get("text", "") + "\n" +
        transcript + "\n" +
        " ".join(image_result.get("observations", []))
    ).lower()

    theme_map = {
        "Latency": ["latency", "slow", "response time"],
        "Errors": ["error", "failure", "exception", "5xx"],
        "Database": ["database", "db", "query", "connection"],
        "Deployment": ["deployment", "release", "rollback"],
        "Capacity": ["capacity", "scale", "cpu", "memory"],
        "Monitoring": ["monitoring", "alert", "dashboard"]
    }

    for theme, keywords in theme_map.items():
        if any(keyword in combined_text for keyword in keywords):
            operational_themes.append(theme)

    severity = "Low"

    if "outage" in combined_text or "critical" in combined_text:
        severity = "High"
    elif "latency" in combined_text or "error" in combined_text:
        severity = "Medium"

    result = {
        "operational_themes": operational_themes,
        "severity": severity,
        "document_keywords": document_keywords,
        "image_observations": image_result.get("observations", []),
        "voice_summary": transcript[:1000],
        "combined_summary": generate_combined_summary(
            operational_themes,
            severity,
            document_keywords,
            transcript
        )
    }

    result["recommendations"] = generate_recommendations(result)

    return result

def generate_combined_summary(themes, severity, document_keywords, transcript):
    return f"""
The multimodal operations copilot analyzed the provided document, image, and voice note.

Detected severity: {severity}

Key operational themes:
{", ".join(themes) if themes else "No major themes detected"}

Document keywords:
{", ".join(document_keywords) if document_keywords else "No operational keywords detected"}

Voice note summary:
{transcript[:700] if transcript else "No voice transcript available."}
"""