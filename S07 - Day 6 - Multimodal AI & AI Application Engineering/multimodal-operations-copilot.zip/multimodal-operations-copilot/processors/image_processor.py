from PIL import Image
from pathlib import Path

def analyze_image(file_path: str):
    image = Image.open(file_path)

    width, height = image.size
    mode = image.mode
    filename = Path(file_path).name

    analysis = {
        "file_path": file_path,
        "filename": filename,
        "width": width,
        "height": height,
        "mode": mode,
        "observations": []
    }

    if width > height:
        analysis["observations"].append("Image appears to be landscape-oriented, likely a dashboard or screenshot.")
    else:
        analysis["observations"].append("Image appears to be portrait-oriented, likely a mobile screenshot or document capture.")

    if width >= 1200:
        analysis["observations"].append("Image has high resolution and may contain detailed operational information.")

    analysis["observations"].append("Manual or model-based visual inspection can be added for charts, alerts, and UI elements.")

    return analysis