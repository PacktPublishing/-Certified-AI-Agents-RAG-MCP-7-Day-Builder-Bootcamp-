import shutil
from pathlib import Path

from fastapi import FastAPI, UploadFile, File

from processors.document_processor import analyze_document
from processors.image_processor import analyze_image
from processors.audio_processor import transcribe_audio
from processors.fusion_engine import fuse_multimodal_inputs
from reports.report_generator import generate_operations_report

app = FastAPI(title="Multimodal Operations Copilot")

UPLOAD_DIR = Path("data/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def save_upload(file: UploadFile):
    path = UPLOAD_DIR / file.filename

    with path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    return str(path)

@app.get("/")
def home():
    return {
        "message": "Multimodal Operations Copilot is running"
    }

@app.post("/analyze")
async def analyze(
    document: UploadFile = File(...),
    image: UploadFile = File(...),
    audio: UploadFile = File(...)
):
    document_path = save_upload(document)
    image_path = save_upload(image)
    audio_path = save_upload(audio)

    document_result = analyze_document(document_path)
    image_result = analyze_image(image_path)
    audio_result = transcribe_audio(audio_path)

    fused_result = fuse_multimodal_inputs(
        document_result,
        image_result,
        audio_result
    )

    report_path, report = generate_operations_report(
        document_result,
        image_result,
        audio_result,
        fused_result
    )

    return {
        "severity": fused_result["severity"],
        "themes": fused_result["operational_themes"],
        "recommendations": fused_result.get("recommendations", []),
        "document_keywords": document_result["keywords"],
        "image_observations": image_result["observations"],
        "voice_transcript": audio_result["transcript"],
        "report_path": report_path,
        "report": report
    }
