from pathlib import Path
from datetime import datetime

def generate_operations_report(document_result, image_result, audio_result, fused_result):
    output_dir = Path("data/outputs")
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"operations_copilot_report_{timestamp}.md"

    report = f"""# Multimodal Operations Copilot Report

## Executive Summary

{fused_result["combined_summary"]}

## Severity

**{fused_result["severity"]}**

## Operational Themes

"""

    for theme in fused_result["operational_themes"]:
        report += f"- {theme}\n"

    report += "\n## Copilot Recommendations\n\n"

    for recommendation in fused_result.get("recommendations", []):
        report += f"- {recommendation}\n"

    report += f"""

## Document Analysis

- File: {document_result["file_path"]}
- Page Count: {document_result["page_count"]}
- Keywords: {", ".join(document_result["keywords"])}

### Document Preview

{document_result["text"][:1500]}

## Image Analysis

- File: {image_result["file_path"]}
- Filename: {image_result["filename"]}
- Dimensions: {image_result["width"]} x {image_result["height"]}
- Mode: {image_result["mode"]}

### Image Observations

"""

    for observation in image_result["observations"]:
        report += f"- {observation}\n"

    if image_result.get("ocr_text"):
        report += f"""

### OCR Text Preview

{image_result["ocr_text"][:1500]}
"""

    report += f"""

## Voice Interaction Analysis

- File: {audio_result["file_path"]}
- Detected Language: {audio_result["language"]}

### Transcript

{audio_result["transcript"]}

## Recommended Actions

1. Validate dashboard metrics against monitoring systems.
2. Review recent deployments or configuration changes.
3. Check database health, capacity, and query performance.
4. Confirm whether customer-facing impact occurred.
5. Escalate to incident commander if severity increases.
6. Create a post-incident review if issue persists.

## Limitations

- Image analysis currently uses metadata and basic heuristic observations.
- Voice transcription should be reviewed before high-risk operational decisions.
- The system can be upgraded with OCR, vision models, and LLM reasoning.
"""

    report_path.write_text(report, encoding="utf-8")

    return str(report_path), report
