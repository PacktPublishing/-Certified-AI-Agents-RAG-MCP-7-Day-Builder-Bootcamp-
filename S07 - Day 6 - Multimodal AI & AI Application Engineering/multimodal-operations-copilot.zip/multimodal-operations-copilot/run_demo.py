from processors.document_processor import analyze_document
from processors.image_processor import analyze_image
from processors.audio_processor import transcribe_audio
from processors.fusion_engine import fuse_multimodal_inputs
from reports.report_generator import generate_operations_report

if __name__ == "__main__":
    document_path = "data/uploads/operations_runbook.pdf"
    image_path = "data/uploads/incident_dashboard.png"
    audio_path = "data/uploads/voice_note.wav"

    print("Analyzing document...")
    document_result = analyze_document(document_path)

    print("Analyzing image...")
    image_result = analyze_image(image_path)

    print("Transcribing voice note...")
    audio_result = transcribe_audio(audio_path)

    print("Fusing multimodal insights...")
    fused_result = fuse_multimodal_inputs(
        document_result,
        image_result,
        audio_result
    )

    print("Generating report...")
    report_path, report = generate_operations_report(
        document_result,
        image_result,
        audio_result,
        fused_result
    )

    print("\nCopilot Report Generated")
    print("------------------------")
    print("Report path:", report_path)
    print("Severity:", fused_result["severity"])
    print("Themes:", fused_result["operational_themes"])
    print("Recommendations:", fused_result.get("recommendations", []))
