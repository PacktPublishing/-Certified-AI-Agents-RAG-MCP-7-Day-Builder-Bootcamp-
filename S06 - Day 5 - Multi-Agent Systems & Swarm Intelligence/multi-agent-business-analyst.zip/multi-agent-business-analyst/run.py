from agents.graph import run_business_analysis

if __name__ == "__main__":
    question = "Which products and regions are driving revenue, profit, and customer conversion?"

    result = run_business_analysis(
        question=question,
        dataset_path="data/sales_data.csv"
    )

    print("\nMulti-Agent Business Analyst Complete")
    print("-------------------------------------")
    print("Report saved to:", result["report_path"])
    print("Chart data saved to:", result["chart_data_path"])

    print("\nReviewer Notes:")
    print(result["review_notes"])
