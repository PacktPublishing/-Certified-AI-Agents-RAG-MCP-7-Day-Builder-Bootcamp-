from typing import TypedDict, List, Dict
from langgraph.graph import StateGraph, END

from agents.planner import planner_agent
from agents.researcher import researcher_agent
from agents.data_analyst import data_analyst_agent
from agents.writer import writer_agent
from agents.reviewer import reviewer_agent
from reports.report_generator import save_report
from reports.chart_exporter import export_chart_data
from memory.memory_store import save_analysis_memory

class BusinessAnalysisState(TypedDict):
    business_question: str
    dataset_path: str
    plan: List[str]
    research_notes: str
    analysis_results: Dict
    draft_report: str
    review_notes: str
    final_report: str
    report_path: str
    approved: bool
    chart_data_path: str

def review_router(state):
    if state["approved"]:
        return "save_report"

    return "writer"

def build_business_graph():
    graph = StateGraph(BusinessAnalysisState)

    graph.add_node("planner", planner_agent)
    graph.add_node("researcher", researcher_agent)
    graph.add_node("data_analyst", data_analyst_agent)
    graph.add_node("writer", writer_agent)
    graph.add_node("reviewer", reviewer_agent)
    graph.add_node("save_report", save_report)

    graph.set_entry_point("planner")

    graph.add_edge("planner", "researcher")
    graph.add_edge("researcher", "data_analyst")
    graph.add_edge("data_analyst", "writer")
    graph.add_edge("writer", "reviewer")

    graph.add_conditional_edges(
        "reviewer",
        review_router,
        {
            "save_report": "save_report",
            "writer": "writer"
        }
    )

    graph.add_edge("save_report", END)

    return graph.compile()

def run_business_analysis(question: str, dataset_path: str):
    app = build_business_graph()

    initial_state = {
        "business_question": question,
        "dataset_path": dataset_path,
        "plan": [],
        "research_notes": "",
        "analysis_results": {},
        "draft_report": "",
        "review_notes": "",
        "final_report": "",
        "report_path": "",
        "approved": False,
        "chart_data_path": ""
    }

    result = app.invoke(initial_state)

    result["chart_data_path"] = export_chart_data(result["analysis_results"])
    save_analysis_memory(result)

    return result    


    