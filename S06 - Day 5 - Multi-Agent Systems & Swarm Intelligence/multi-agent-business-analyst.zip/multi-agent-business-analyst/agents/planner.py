def planner_agent(state):
    question = state["business_question"]

    plan = [
        "Understand the business question",
        "Review available dataset fields",
        "Research relevant business context",
        "Analyze revenue, expenses, customers, and conversion trends",
        "Identify regional and product performance patterns",
        "Generate a business intelligence report",
        "Review the report for completeness and executive usefulness"
    ]

    state["plan"] = plan
    return state
