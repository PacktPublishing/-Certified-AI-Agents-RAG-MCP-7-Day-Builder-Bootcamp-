def researcher_agent(state):
    question = state["business_question"]

    research_notes = f"""
Business Context for Analysis:

Question:
{question}

The business is evaluating product and regional performance across AI software products.

Important dimensions:
- Revenue growth
- Expense control
- Profitability
- Customer acquisition
- Conversion rates
- Regional performance
- Product performance

The report should focus on executive insights, risks, and recommended actions.
"""

    state["research_notes"] = research_notes
    return state