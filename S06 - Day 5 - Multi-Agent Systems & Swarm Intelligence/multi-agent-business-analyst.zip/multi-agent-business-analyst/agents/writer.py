def writer_agent(state):
    question = state["business_question"]
    plan = state["plan"]
    research_notes = state["research_notes"]
    analysis = state["analysis_results"]

    report = f"""
# Multi-Agent Business Intelligence Report

## Business Question

{question}

## Executive Summary

The multi-agent business analyst system reviewed the sales dataset, evaluated revenue, expenses, profitability, customers, and conversion rates, and generated insights across product and regional performance.

## Analysis Plan

"""

    for step in plan:
        report += f"- {step}\n"

    report += f"""

## Business Context

{research_notes}

## Key Metrics

- Total Revenue: ${analysis["total_revenue"]:,.2f}
- Total Expenses: ${analysis["total_expenses"]:,.2f}
- Total Profit: ${analysis["total_profit"]:,.2f}
- Average Conversion Rate: {analysis["average_conversion_rate"]:.2f}%

## Revenue by Region

"""

    for region, revenue in analysis["revenue_by_region"].items():
        report += f"- {region}: ${revenue:,.2f}\n"

    report += """

## Revenue by Product

"""

    for product, revenue in analysis["revenue_by_product"].items():
        report += f"- {product}: ${revenue:,.2f}\n"

    report += """

## Profit by Region

"""

    for region, profit in analysis["profit_by_region"].items():
        report += f"- {region}: ${profit:,.2f}\n"

    report += """

## Monthly Revenue

"""

    for month, revenue in analysis["monthly_revenue"].items():
        report += f"- {month}: ${revenue:,.2f}\n"

    report += f"""

## Top Performers

- Best Region by Revenue: {analysis["best_region"]}
- Best Product by Revenue: {analysis["best_product"]}

## Recommendations

1. Increase investment in the strongest region and product category.
2. Review expense patterns in lower-profit regions.
3. Improve conversion rates in underperforming markets.
4. Continue monitoring monthly revenue growth.
5. Use this analysis as a baseline for future forecasting.

## Conclusion

The business shows positive revenue and profit performance, with clear opportunities to optimize regional strategy, product investment, and customer conversion.
"""

    state["draft_report"] = report
    return state