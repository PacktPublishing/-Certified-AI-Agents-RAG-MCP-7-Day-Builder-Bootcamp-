import pandas as pd

def data_analyst_agent(state):
    dataset_path = state["dataset_path"]

    df = pd.read_csv(dataset_path)

    df["profit"] = df["revenue"] - df["expenses"]
    df["profit_margin"] = (df["profit"] / df["revenue"]) * 100

    total_revenue = df["revenue"].sum()
    total_expenses = df["expenses"].sum()
    total_profit = df["profit"].sum()
    avg_conversion = df["conversion_rate"].mean()

    revenue_by_region = (
        df.groupby("region")["revenue"]
        .sum()
        .sort_values(ascending=False)
        .to_dict()
    )

    revenue_by_product = (
        df.groupby("product")["revenue"]
        .sum()
        .sort_values(ascending=False)
        .to_dict()
    )

    profit_by_region = (
        df.groupby("region")["profit"]
        .sum()
        .sort_values(ascending=False)
        .to_dict()
    )

    monthly_revenue = (
        df.groupby("month")["revenue"]
        .sum()
        .to_dict()
    )

    best_region = max(revenue_by_region, key=revenue_by_region.get)
    best_product = max(revenue_by_product, key=revenue_by_product.get)

    analysis_results = {
        "total_revenue": float(total_revenue),
        "total_expenses": float(total_expenses),
        "total_profit": float(total_profit),
        "average_conversion_rate": float(avg_conversion),
        "revenue_by_region": revenue_by_region,
        "revenue_by_product": revenue_by_product,
        "profit_by_region": profit_by_region,
        "monthly_revenue": monthly_revenue,
        "best_region": best_region,
        "best_product": best_product
    }

    state["analysis_results"] = analysis_results
    return state
