def reviewer_agent(state):
    report = state["draft_report"]
    analysis = state["analysis_results"]

    review_notes = []
    approved = True

    if "Executive Summary" not in report:
        review_notes.append("Missing executive summary.")
        approved = False

    if "Recommendations" not in report:
        review_notes.append("Missing recommendations.")
        approved = False

    if analysis["total_profit"] <= 0:
        review_notes.append("Profit is negative or zero. Add stronger risk guidance.")
        approved = False

    if analysis["average_conversion_rate"] < 4:
        review_notes.append("Conversion rate is low. Add conversion improvement recommendations.")

    if approved:
        review_notes.append("Approved for final delivery.")

    state["review_notes"] = "\n".join(review_notes)

    state["final_report"] = report + f"""

---

## Reviewer Notes

{state["review_notes"]}
"""

    state["approved"] = approved

    return state