from fastapi import FastAPI
from pydantic import BaseModel
from agents.graph import run_business_analysis

app = FastAPI(title="Multi-Agent Business Analyst")

class AnalysisRequest(BaseModel):
    question: str
    dataset_path: str = "data/sales_data.csv"

@app.get("/")
def home():
    return {
        "message": "Multi-Agent Business Analyst is running"
    }

@app.post("/analyze")
def analyze(request: AnalysisRequest):
    result = run_business_analysis(
        question=request.question,
        dataset_path=request.dataset_path
    )

    return {
        "question": result["business_question"],
        "plan": result["plan"],
        "analysis_results": result["analysis_results"],
        "review_notes": result["review_notes"],
        "final_report": result["final_report"],
        "report_path": result["report_path"],
        "chart_data_path": result["chart_data_path"]
    }