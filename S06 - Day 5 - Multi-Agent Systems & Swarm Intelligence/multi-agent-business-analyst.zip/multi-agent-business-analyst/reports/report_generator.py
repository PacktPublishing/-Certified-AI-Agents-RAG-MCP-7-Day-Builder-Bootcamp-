from pathlib import Path
from datetime import datetime

def save_report(state):
    output_dir = Path("reports/outputs")
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = output_dir / f"business_intelligence_report_{timestamp}.md"

    report_path.write_text(state["final_report"], encoding="utf-8")

    state["report_path"] = str(report_path)
    return state
    