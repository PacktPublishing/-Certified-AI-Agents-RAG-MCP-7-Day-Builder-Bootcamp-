import json
from pathlib import Path
from datetime import datetime

def export_chart_data(analysis_results):
    output_dir = Path("reports/outputs")
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = output_dir / f"chart_data_{timestamp}.json"

    chart_data = {
        "revenue_by_region": analysis_results["revenue_by_region"],
        "revenue_by_product": analysis_results["revenue_by_product"],
        "monthly_revenue": analysis_results["monthly_revenue"]
    }

    path.write_text(json.dumps(chart_data, indent=2), encoding="utf-8")

    return str(path)
