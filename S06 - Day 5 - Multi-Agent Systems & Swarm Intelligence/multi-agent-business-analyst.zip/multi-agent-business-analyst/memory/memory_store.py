import json
from pathlib import Path
from datetime import datetime

MEMORY_FILE = Path("memory/analysis_history.jsonl")

def save_analysis_memory(result):
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)

    record = {
        "timestamp": datetime.now().isoformat(),
        "question": result["business_question"],
        "analysis_results": result["analysis_results"],
        "report_path": result["report_path"]
    }

    with MEMORY_FILE.open("a", encoding="utf-8") as file:
        file.write(json.dumps(record) + "\n")
