def build_citations(retrieved_chunks):
    citations = []

    seen = set()

    for index, chunk in enumerate(retrieved_chunks, start=1):
        key = f'{chunk["source"]}-p{chunk["page"]}'

        if key in seen:
            continue

        seen.add(key)

        citations.append({
            "citation_id": index,
            "source": chunk["source"],
            "page": chunk["page"],
            "label": f'[{index}] {chunk["source"]}, page {chunk["page"]}'
        })

    return citations

def format_context_with_citations(retrieved_chunks):
    context = ""

    for index, chunk in enumerate(retrieved_chunks, start=1):
        context += f"""
[Citation {index}]
Source: {chunk["source"]}
Page: {chunk["page"]}
Text:
{chunk["text"]}
"""

    return context