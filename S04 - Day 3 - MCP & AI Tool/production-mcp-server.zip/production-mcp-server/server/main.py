from mcp.server.fastmcp import FastMCP

from database.db import init_db
from tools.customer_tools import search_customers, get_customer_tickets
from tools.api_tools import get_external_api_status, get_github_repo_info
from tools.report_tools import generate_customer_report
from auth.audit import log_event

mcp = FastMCP("Production MCP Server")

@mcp.tool()
def search_customer_database(api_key: str, query: str) -> list:
    """Search customers by name or email."""
    log_event("tool_call", {"tool": "search_customer_database", "query": query})
    return search_customers(api_key, query)

@mcp.tool()
def get_tickets_for_customer(api_key: str, customer_id: int) -> list:
    """Get support tickets for a customer ID."""
    log_event("tool_call", {"tool": "get_tickets_for_customer", "customer_id": customer_id})
    return get_customer_tickets(api_key, customer_id)

@mcp.tool()
def check_external_api(api_key: str) -> dict:
    """Check whether the external API is reachable."""
    log_event("tool_call", {"tool": "check_external_api"})
    return get_external_api_status(api_key)

@mcp.tool()
def github_repository_info(api_key: str, owner: str, repo: str) -> dict:
    """Retrieve public GitHub repository metadata."""
    log_event("tool_call", {"tool": "github_repository_info", "owner": owner, "repo": repo})
    return get_github_repo_info(api_key, owner, repo)

@mcp.tool()
def create_customer_report(api_key: str, customer_name: str, summary: str) -> dict:
    """Create a markdown customer report."""
    log_event("tool_call", {"tool": "create_customer_report", "customer_name": customer_name})
    return generate_customer_report(api_key, customer_name, summary)

@mcp.resource("schema://customers")
def customer_schema() -> str:
    """Provide database schema information for customers."""
    return """
customers:
- id: integer
- name: text
- email: text
- account_tier: text
- risk_score: integer

tickets:
- id: integer
- customer_id: integer
- title: text
- status: text
- priority: text
"""

if __name__ == "__main__":
    init_db()
    mcp.run()
