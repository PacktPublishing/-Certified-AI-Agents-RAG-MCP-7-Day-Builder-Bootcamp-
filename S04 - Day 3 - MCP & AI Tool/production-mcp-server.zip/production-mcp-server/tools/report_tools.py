from pathlib import Path
from datetime import datetime
from auth.security import require_api_key

OUTPUT_DIR = Path("data/outputs")

def generate_customer_report(api_key: str, customer_name: str, summary: str):
    require_api_key(api_key)

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"customer_report_{timestamp}.md"
    path = OUTPUT_DIR / filename

    content = f"""# Customer Report

## Customer
{customer_name}

## Summary
{summary}

## Generated At
{datetime.now().isoformat()}
"""

    path.write_text(content, encoding="utf-8")

    return {
        "file": str(path),
        "content": content
    }
