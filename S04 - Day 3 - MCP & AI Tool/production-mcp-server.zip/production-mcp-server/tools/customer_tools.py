from database.db import get_connection
from auth.security import require_api_key

def validate_query(query: str):
    if not query or len(query.strip()) < 2:
        raise ValueError("Query must be at least 2 characters.")

    if len(query) > 100:
        raise ValueError("Query is too long.")

def search_customers(api_key: str, query: str):
    require_api_key(api_key)
    validate_query(query)

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id, name, email, account_tier, risk_score
    FROM customers
    WHERE name LIKE ? OR email LIKE ?
    """, (f"%{query}%", f"%{query}%"))

    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "id": row[0],
            "name": row[1],
            "email": row[2],
            "account_tier": row[3],
            "risk_score": row[4]
        }
        for row in rows
    ]

def get_customer_tickets(api_key: str, customer_id: int):
    require_api_key(api_key)

    if customer_id <= 0:
        raise ValueError("customer_id must be positive.")

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    SELECT id, title, status, priority
    FROM tickets
    WHERE customer_id = ?
    """, (customer_id,))

    rows = cursor.fetchall()
    conn.close()

    return [
        {
            "id": row[0],
            "title": row[1],
            "status": row[2],
            "priority": row[3]
        }
        for row in rows
    ]