import os
import requests
from dotenv import load_dotenv
from auth.security import require_api_key

load_dotenv()

EXTERNAL_API_URL = os.getenv("EXTERNAL_API_URL", "https://api.github.com")

def get_external_api_status(api_key: str):
    require_api_key(api_key)

    response = requests.get(EXTERNAL_API_URL, timeout=10)

    return {
        "url": EXTERNAL_API_URL,
        "status_code": response.status_code,
        "ok": response.ok
    }

def get_github_repo_info(api_key: str, owner: str, repo: str):
    require_api_key(api_key)

    url = f"https://api.github.com/repos/{owner}/{repo}"
    response = requests.get(url, timeout=10)

    if response.status_code != 200:
        return {
            "error": "Repository not found or API unavailable",
            "status_code": response.status_code
        }

    data = response.json()

    return {
        "name": data.get("name"),
        "full_name": data.get("full_name"),
        "description": data.get("description"),
        "stars": data.get("stargazers_count"),
        "forks": data.get("forks_count"),
        "open_issues": data.get("open_issues_count"),
        "url": data.get("html_url")
    }