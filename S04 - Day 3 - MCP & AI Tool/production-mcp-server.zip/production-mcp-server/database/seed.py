from database.db import get_connection, init_db

def seed_data():
    init_db()

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM tickets")
    cursor.execute("DELETE FROM customers")

    customers = [
        ("Acme Corp", "admin@acme.com", "Enterprise", 82),
        ("Delta Systems", "ops@delta.com", "Business", 45),
        ("Nova Retail", "support@nova.com", "Starter", 30)
    ]

    cursor.executemany("""
    INSERT INTO customers (name, email, account_tier, risk_score)
    VALUES (?, ?, ?, ?)
    """, customers)

    tickets = [
        (1, "Login failures in production", "Open", "High"),
        (1, "Billing sync issue", "Open", "Medium"),
        (2, "Dashboard loading slowly", "Closed", "Low"),
        (3, "Upgrade plan request", "Open", "Low")
    ]

    cursor.executemany("""
    INSERT INTO tickets (customer_id, title, status, priority)
    VALUES (?, ?, ?, ?)
    """, tickets)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    seed_data()
