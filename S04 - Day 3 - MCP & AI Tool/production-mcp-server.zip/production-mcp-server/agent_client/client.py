API_KEY = "dev-secret-123"

def run_demo_agent():
    print("Demo Agent: Enterprise Customer Research")

    print("\nStep 1: Search customer database")
    print("Tool: search_customer_database")
    print("Input:", {"api_key": API_KEY, "query": "Acme"})

    print("\nStep 2: Retrieve tickets")
    print("Tool: get_tickets_for_customer")
    print("Input:", {"api_key": API_KEY, "customer_id": 1})

    print("\nStep 3: Check external API")
    print("Tool: check_external_api")
    print("Input:", {"api_key": API_KEY})

    print("\nStep 4: Generate report")
    print("Tool: create_customer_report")
    print("Input:", {
        "api_key": API_KEY,
        "customer_name": "Acme Corp",
        "summary": "Customer has open production issues and requires executive escalation."
    })

    print("\nAgent Plan Complete.")
    print("Now test these tool calls in MCP Inspector or connect to an MCP-compatible client.")

if __name__ == "__main__":
    run_demo_agent()