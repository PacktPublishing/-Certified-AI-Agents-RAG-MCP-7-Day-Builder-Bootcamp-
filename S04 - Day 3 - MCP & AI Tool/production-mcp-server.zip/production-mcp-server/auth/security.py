import os
from dotenv import load_dotenv

load_dotenv()

EXPECTED_API_KEY = os.getenv("MCP_API_KEY")

def verify_api_key(api_key: str) -> bool:
    if not EXPECTED_API_KEY:
        raise RuntimeError("MCP_API_KEY is missing from environment.")

    return api_key == EXPECTED_API_KEY

def require_api_key(api_key: str):
    if not verify_api_key(api_key):
        raise PermissionError("Invalid API key.")

    return True