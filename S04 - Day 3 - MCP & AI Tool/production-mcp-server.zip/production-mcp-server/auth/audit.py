from pathlib import Path
from datetime import datetime
import json

AUDIT_FILE = Path("data/audit.log")

def log_event(event_type: str, details: dict):
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)

    event = {
        "timestamp": datetime.now().isoformat(),
        "event_type": event_type,
        "details": details
    }

    with AUDIT_FILE.open("a", encoding="utf-8") as file:
        file.write(json.dumps(event) + "\n")
