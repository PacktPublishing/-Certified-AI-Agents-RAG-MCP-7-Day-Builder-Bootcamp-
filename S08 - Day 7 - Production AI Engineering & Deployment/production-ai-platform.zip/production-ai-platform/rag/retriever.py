import chromadb
from sentence_transformers import SentenceTransformer

DB_PATH = "data/chroma_db"
COLLECTION_NAME = "enterprise_knowledge"

model = SentenceTransformer("all-MiniLM-L6-v2")

def retrieve_context(query: str, top_k: int = 4):
    client = chromadb.PersistentClient(path=DB_PATH)
    collection = client.get_or_create_collection(COLLECTION_NAME)

    query_embedding = model.encode(query).tolist()

    results = collection.query(
        query_embeddings=[query_embedding],
        n_results=top_k
    )

    contexts = []

    for text, metadata, doc_id in zip(
        results["documents"][0],
        results["metadatas"][0],
        results["ids"][0]
    ):
        contexts.append({
            "id": doc_id,
            "text": text,
            "source": metadata["source"]
        })

    return contexts
