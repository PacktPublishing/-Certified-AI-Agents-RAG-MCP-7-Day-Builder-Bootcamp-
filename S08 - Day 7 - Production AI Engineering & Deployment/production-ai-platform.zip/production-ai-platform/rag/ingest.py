from pathlib import Path
import chromadb
from sentence_transformers import SentenceTransformer

DOCS_DIR = Path("data/docs")
DB_PATH = "data/chroma_db"
COLLECTION_NAME = "enterprise_knowledge"

model = SentenceTransformer("all-MiniLM-L6-v2")

def chunk_text(text: str, chunk_size: int = 500):
    words = text.split()
    chunks = []

    for i in range(0, len(words), chunk_size):
        chunks.append(" ".join(words[i:i + chunk_size]))

    return chunks

def load_documents():
    documents = []

    for path in DOCS_DIR.glob("*.txt"):
        text = path.read_text(encoding="utf-8")

        for index, chunk in enumerate(chunk_text(text)):
            documents.append({
                "id": f"{path.stem}-{index}",
                "source": path.name,
                "text": chunk
            })

    return documents

def ingest_documents():
    client = chromadb.PersistentClient(path=DB_PATH)
    collection = client.get_or_create_collection(COLLECTION_NAME)

    docs = load_documents()

    for doc in docs:
        embedding = model.encode(doc["text"]).tolist()

        collection.upsert(
            ids=[doc["id"]],
            documents=[doc["text"]],
            embeddings=[embedding],
            metadatas=[{"source": doc["source"]}]
        )

    return {
        "documents_indexed": len(docs)
    }

if __name__ == "__main__":
    print(ingest_documents())
