def evaluate_output(result):
    report = result["final_report"]
    context = result["research_context"]

    scores = {
        "has_sources": 1 if len(context) > 0 else 0,
        "has_recommendations": 1 if "Recommendations" in report else 0,
        "has_review": 1 if "Reviewer Notes" in report else 0,
        "length_score": 1 if len(report) > 500 else 0
    }

    total = sum(scores.values())
    max_score = len(scores)

    return {
        "scores": scores,
        "total_score": total,
        "max_score": max_score,
        "percentage": round((total / max_score) * 100, 2),
        "passed": total >= 3
    }