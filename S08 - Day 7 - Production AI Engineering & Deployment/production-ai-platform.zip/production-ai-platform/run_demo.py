from rag.ingest import ingest_documents
from agents.graph import run_platform
from evaluation.evaluator import evaluate_output

if __name__ == "__main__":
    question = "How should an enterprise deploy governed AI agents with RAG, monitoring, and approval workflows?"

    print("Ingesting documents...")
    ingest_result = ingest_documents()
    print("Ingestion result:", ingest_result)

    print("\nRunning production AI platform...")
    result = run_platform(question)

    print("\nEvaluating output...")
    evaluation = evaluate_output(result)

    print("\nProduction AI Platform Complete")
    print("-------------------------------")
    print("Question:", result["question"])
    print("Report saved to:", result["report_path"])
    print("Review notes:", result["review_notes"])
    print("Evaluation:", evaluation)
