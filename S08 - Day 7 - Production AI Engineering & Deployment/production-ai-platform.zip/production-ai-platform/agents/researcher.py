from mcp_tools.tools import search_enterprise_knowledge

def researcher_agent(state):
    question = state["question"]

    context = search_enterprise_knowledge(question)

    state["research_context"] = context

    return state