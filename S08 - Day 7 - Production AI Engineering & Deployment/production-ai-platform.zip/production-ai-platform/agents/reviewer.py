def reviewer_agent(state):
    report = state["draft_report"]
    notes = []
    approved = True

    required_sections = [
        "Question",
        "Execution Plan",
        "Retrieved Enterprise Context",
        "Analysis",
        "Recommendations",
        "Conclusion"
    ]

    for section in required_sections:
        if section not in report:
            notes.append(f"Missing section: {section}")
            approved = False

    if len(report) < 500:
        notes.append("Report is too short for executive review.")
        approved = False

    if approved:
        notes.append("Approved. Report is complete and portfolio-ready.")

    state["review_notes"] = "\n".join(notes)
    state["approved"] = approved
