from mcp_tools.tools import calculate_business_score

def analyst_agent(state):
    context = state["research_context"]

    combined_context = " ".join([item["text"] for item in context]).lower()

    risk = 5
    urgency = 5
    impact = 5

    if "governance" in combined_context:
        risk += 2

    if "monitoring" in combined_context:
        urgency += 1

    if "human approval" in combined_context:
        impact += 2

    score = calculate_business_score(
        impact=min(impact, 10),
        urgency=min(urgency, 10),
        risk=min(risk, 10)
    )

    state["analysis"] = {
        "priority_score": score,
        "key_themes": extract_themes(combined_context),
        "source_count": len(context)
    }

    return state

def extract_themes(text: str):
    themes = []

    theme_map = {
        "Governance": ["governance", "policy", "approval"],
        "Monitoring": ["monitoring", "observability", "metrics"],
        "RAG": ["retrieval", "rag", "context"],
        "Security": ["access control", "audit", "security"],
        "Deployment": ["deployment", "production"]
    }

    for theme, keywords in theme_map.items():
        if any(keyword in text for keyword in keywords):
            themes.append(theme)

    return themes
