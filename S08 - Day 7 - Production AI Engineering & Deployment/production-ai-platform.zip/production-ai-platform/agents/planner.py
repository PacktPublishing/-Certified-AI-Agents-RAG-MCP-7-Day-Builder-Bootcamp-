def planner_agent(state):
    question = state["question"]

    state["plan"] = [
        "Understand the user question",
        "Retrieve relevant enterprise knowledge",
        "Analyze risks, actions, and recommendations",
        "Generate a structured business report",
        "Review the report for quality",
        "Save the final report"
    ]

    return state