def writer_agent(state):
    question = state["question"]
    plan = state["plan"]
    context = state["research_context"]
    analysis = state["analysis"]

    report = f"""# Production AI Platform Report

## Question

{question}

## Execution Plan

"""

    for step in plan:
        report += f"- {step}\n"

    report += """

## Retrieved Enterprise Context

"""

    for item in context:
        report += f"""
### Source: {item["source"]}

{item["text"]}
"""

    report += f"""

## Analysis

- Source Count: {analysis["source_count"]}
- Key Themes: {", ".join(analysis["key_themes"])}
- Priority Score: {analysis["priority_score"]["priority_score"]}

## Recommendations

1. Use RAG for grounded enterprise responses.
2. Use multi-agent orchestration for complex workflows.
3. Add evaluation before release.
4. Add monitoring for reliability and cost tracking.
5. Require human approval for high-risk actions.

## Conclusion

This platform demonstrates a production-style AI architecture combining agents, RAG, MCP-style tools, evaluation, monitoring, API serving, and local report generation.
"""

    state["draft_report"] = report
    return state