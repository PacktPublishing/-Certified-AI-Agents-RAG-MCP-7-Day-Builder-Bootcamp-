from typing import TypedDict, List, Dict
from langgraph.graph import StateGraph, END

from agents.planner import planner_agent
from agents.researcher import researcher_agent
from agents.analyst import analyst_agent
from agents.writer import writer_agent
from agents.reviewer import reviewer_agent
from agents.save_report import save_report_agent

class PlatformState(TypedDict):
    question: str
    plan: List[str]
    research_context: List[Dict]
    analysis: Dict
    draft_report: str
    review_notes: str
    final_report: str
    report_path: str
    approved: bool

def review_router(state):
    if state["approved"]:
        return "save_report"

    return "writer"

def build_platform_graph():
    graph = StateGraph(PlatformState)

    graph.add_node("planner", planner_agent)
    graph.add_node("researcher", researcher_agent)
    graph.add_node("analyst", analyst_agent)
    graph.add_node("writer", writer_agent)
    graph.add_node("reviewer", reviewer_agent)
    graph.add_node("save_report", save_report_agent)

    graph.set_entry_point("planner")

    graph.add_edge("planner", "researcher")
    graph.add_edge("researcher", "analyst")
    graph.add_edge("analyst", "writer")
    graph.add_edge("writer", "reviewer")

    graph.add_conditional_edges(
        "reviewer",
        review_router,
        {
            "save_report": "save_report",
            "writer": "writer"
        }
    )

    graph.add_edge("save_report", END)

    return graph.compile()

def run_platform(question: str):
    app = build_platform_graph()

    initial_state = {
        "question": question,
        "plan": [],
        "research_context": [],
        "analysis": {},
        "draft_report": "",
        "review_notes": "",
        "final_report": "",
        "report_path": "",
        "approved": False
    }

    return app.invoke(initial_state)
    