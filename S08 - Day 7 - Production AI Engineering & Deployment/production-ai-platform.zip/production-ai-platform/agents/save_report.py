from mcp_tools.tools import save_report_file

def save_report_agent(state):
    result = save_report_file(
        title="Production AI Platform Report",
        content=state["final_report"]
    )

    state["report_path"] = result["path"]

    return state
