from pydantic import BaseModel

class PlatformRequest(BaseModel):
    question: str

class PlatformResponse(BaseModel):
    question: str
    final_report: str
    report_path: str
    evaluation: dict