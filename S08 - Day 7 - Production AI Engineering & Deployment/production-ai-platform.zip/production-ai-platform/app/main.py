from fastapi import FastAPI
from app.schemas import PlatformRequest
from agents.graph import run_platform
from evaluation.evaluator import evaluate_output
from monitoring.metrics import setup_metrics
from rag.ingest import ingest_documents

app = FastAPI(title="Production AI Platform")

setup_metrics(app)

@app.on_event("startup")
def startup_event():
    ingest_documents()

@app.get("/")
def home():
    return {
        "message": "Production AI Platform is running"
    }

@app.post("/run")
def run(request: PlatformRequest):
    result = run_platform(request.question)
    evaluation = evaluate_output(result)

    return {
        "question": result["question"],
        "plan": result["plan"],
        "analysis": result["analysis"],
        "review_notes": result["review_notes"],
        "final_report": result["final_report"],
        "report_path": result["report_path"],
        "evaluation": evaluation
    }

@app.get("/health")
def health():
    return {
        "status": "ok"
    }