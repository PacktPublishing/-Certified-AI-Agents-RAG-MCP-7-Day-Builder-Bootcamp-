from datetime import datetime
from pathlib import Path
from rag.retriever import retrieve_context

OUTPUT_DIR = Path("data/outputs")

def search_enterprise_knowledge(query: str):
    """MCP-style tool for enterprise knowledge search."""
    return retrieve_context(query)

def calculate_business_score(impact: int, urgency: int, risk: int):
    """MCP-style tool for scoring business priority."""
    score = (impact * 0.4) + (urgency * 0.4) + (risk * 0.2)

    return {
        "impact": impact,
        "urgency": urgency,
        "risk": risk,
        "priority_score": round(score, 2)
    }

def save_report_file(title: str, content: str):
    """MCP-style tool for writing report files."""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    safe_title = title.lower().replace(" ", "_")[:50]
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    path = OUTPUT_DIR / f"{safe_title}_{timestamp}.md"

    path.write_text(content, encoding="utf-8")

    return {
        "path": str(path)
    }