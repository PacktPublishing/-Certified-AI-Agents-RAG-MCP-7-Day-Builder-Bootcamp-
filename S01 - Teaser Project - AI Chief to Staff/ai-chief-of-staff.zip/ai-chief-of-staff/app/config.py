import os
from dotenv import load_dotenv

load_dotenv()

MODEL_PROVIDER = os.getenv("MODEL_PROVIDER", "ollama")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1")
VECTOR_DB_PATH = os.getenv("VECTOR_DB_PATH", "./data/vector_db")
DOCS_PATH = os.getenv("DOCS_PATH", "./data/docs")
OUTPUT_PATH = os.getenv("OUTPUT_PATH", "./data/outputs")